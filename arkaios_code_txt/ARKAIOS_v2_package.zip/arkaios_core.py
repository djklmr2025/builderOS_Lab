#! /usr/bin/env python3
# Núcleo mínimo de ARKAIOS – placeholder
print('ARKAIOS core placeholder')
